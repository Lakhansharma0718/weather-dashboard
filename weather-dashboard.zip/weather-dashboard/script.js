const form=document.querySelector("#searchForm");
const cityInput=document.querySelector("#cityInput");
const searchButton=document.querySelector("#searchButton");
const statusEl=document.querySelector("#status");
const weatherSection=document.querySelector("#weather");

const weatherDescriptions={
  0:["Clear sky","☀️"],1:["Mainly clear","🌤️"],2:["Partly cloudy","⛅"],3:["Overcast","☁️"],
  45:["Fog","🌫️"],48:["Depositing rime fog","🌫️"],
  51:["Light drizzle","🌦️"],53:["Moderate drizzle","🌦️"],55:["Dense drizzle","🌧️"],
  56:["Freezing drizzle","🌧️"],57:["Dense freezing drizzle","🌧️"],
  61:["Slight rain","🌦️"],63:["Moderate rain","🌧️"],65:["Heavy rain","🌧️"],
  66:["Freezing rain","🌧️"],67:["Heavy freezing rain","🌧️"],
  71:["Slight snow","🌨️"],73:["Moderate snow","🌨️"],75:["Heavy snow","❄️"],77:["Snow grains","❄️"],
  80:["Rain showers","🌦️"],81:["Moderate showers","🌧️"],82:["Violent showers","⛈️"],
  85:["Snow showers","🌨️"],86:["Heavy snow showers","❄️"],
  95:["Thunderstorm","⛈️"],96:["Thunderstorm with hail","⛈️"],99:["Thunderstorm with heavy hail","⛈️"]
};

async function getJSON(url){
  const response=await fetch(url);
  if(!response.ok) throw new Error(`Request failed (${response.status}). Please try again.`);
  const data=await response.json();
  if(data.error) throw new Error(data.reason||"Weather service returned an error.");
  return data;
}

async function loadWeather(city){
  setLoading(true);
  statusEl.className="status";
  statusEl.textContent=`Searching weather for ${city}…`;
  weatherSection.hidden=true;
  try{
    // Step 1: Convert city name into latitude and longitude.
    const geoURL=`https://geocoding-api.open-meteo.com/v1/search?${new URLSearchParams({name:city,count:1,language:"en",format:"json"})}`;
    const geo=await getJSON(geoURL);
    if(!geo.results?.length) throw new Error(`We couldn't find "${city}". Check the spelling and try another city.`);
    const place=geo.results[0];

    // Step 2: Fetch current conditions and a 5-day daily forecast.
    const params=new URLSearchParams({
      latitude:place.latitude,longitude:place.longitude,
      current:"temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m,wind_direction_10m",
      daily:"weather_code,temperature_2m_max,temperature_2m_min",
      temperature_unit:"celsius",wind_speed_unit:"kmh",timezone:"auto",forecast_days:"5"
    });
    const data=await getJSON(`https://api.open-meteo.com/v1/forecast?${params}`);
    renderWeather(place,data);
    statusEl.textContent=`Weather updated for ${place.name}.`;
    weatherSection.hidden=false;
  }catch(error){
    statusEl.className="status error";
    statusEl.textContent=error.message.includes("Failed to fetch")
      ?"Network error. Check your internet connection and try again."
      :error.message;
  }finally{setLoading(false);}
}

function renderWeather(place,data){
  const c=data.current,d=data.daily;
  const [description,icon]=weatherDescriptions[c.weather_code]||["Weather unavailable","🌡️"];
  document.querySelector("#location").textContent=[place.name,place.admin1,place.country].filter(Boolean).join(", ");
  document.querySelector("#localTime").textContent=`Local time · ${c.time.replace("T"," ")}`;
  document.querySelector("#temperature").textContent=Math.round(c.temperature_2m);
  document.querySelector("#condition").textContent=description;
  document.querySelector("#weatherIcon").textContent=icon;
  document.querySelector("#feelsLike").textContent=Math.round(c.apparent_temperature);
  document.querySelector("#highLow").textContent=`H ${Math.round(d.temperature_2m_max[0])}°  ·  L ${Math.round(d.temperature_2m_min[0])}°`;
  document.querySelector("#humidity").textContent=`${c.relative_humidity_2m}%`;
  document.querySelector("#wind").textContent=`${Math.round(c.wind_speed_10m)} km/h`;
  document.querySelector("#windDirection").textContent=`Direction ${Math.round(c.wind_direction_10m)}°`;
  document.querySelector("#feelsMetric").textContent=`${Math.round(c.apparent_temperature)}°C`;
  document.querySelector("#rain").textContent=`${c.precipitation} mm`;
  const forecast=document.querySelector("#forecast");
  forecast.replaceChildren();
  d.time.forEach((date,index)=>{
    const [label,emoji]=weatherDescriptions[d.weather_code[index]]||["Unknown","🌡️"];
    const day=document.createElement("article");day.className="day";
    const dateObj=new Date(`${date}T12:00:00`);
    const name=document.createElement("div");name.className="day-name";
    name.textContent=index===0?"Today":new Intl.DateTimeFormat("en",{weekday:"short"}).format(dateObj);
    const iconEl=document.createElement("div");iconEl.className="day-icon";iconEl.textContent=emoji;
    const condition=document.createElement("div");condition.className="day-condition";condition.textContent=label;
    const temps=document.createElement("div");temps.className="day-temps";
    temps.textContent=`${Math.round(d.temperature_2m_max[index])}°`;
    const low=document.createElement("span");low.textContent=`${Math.round(d.temperature_2m_min[index])}°`;
    temps.append(low);day.append(name,iconEl,condition,temps);forecast.append(day);
  });
}
function setLoading(loading){searchButton.disabled=loading;searchButton.innerHTML=loading?"Loading…":"Search <span>→</span>"}
form.addEventListener("submit",event=>{event.preventDefault();const city=cityInput.value.trim();if(city)loadWeather(city)});
loadWeather(cityInput.value);
