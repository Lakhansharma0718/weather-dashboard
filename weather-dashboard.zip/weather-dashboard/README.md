# SkyCast — Real-Time Weather Dashboard

A responsive weather dashboard built with HTML, CSS and vanilla JavaScript. It uses the Open-Meteo Geocoding and Forecast REST APIs.

## Features
- Search weather by city name
- Fetch API with async/await
- Current temperature, humidity, apparent temperature, wind speed/direction and precipitation
- Five-day forecast with weather descriptions and icons
- Dynamic rendering from nested JSON data
- Loading state, empty city result, HTTP/API and network error handling
- Responsive layout
- No API key or package installation required

## Run locally
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Open `index.html` using Live Server (recommended), or open it directly in a modern browser.
4. Search for a city such as Jaipur, Delhi, Mumbai or London.

Internet access is required because weather and geocoding data are fetched live.

## APIs
- Geocoding: `https://geocoding-api.open-meteo.com/v1/search`
- Forecast: `https://api.open-meteo.com/v1/forecast`

Open-Meteo offers free non-commercial access without an API key. Please retain attribution to Open-Meteo: https://open-meteo.com/

## GitHub
Create a public repository named `weather-dashboard`, then run in this folder:

```bash
git init
git add .
git commit -m "Real-Time Weather Dashboard"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/weather-dashboard.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username.
